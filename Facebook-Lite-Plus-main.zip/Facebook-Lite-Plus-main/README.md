# Facebook Lite Plus
Facebook Lite Plus is lite weight android app for login into Facebook accounts with many featurs.

- [DESCRIPTION](#description)
- [FEATURES](#features)
- [IMAGES](#images)
- [FUTURE UPDATES](#future-updates)
- [DOWNLOAD](#download)
#
# DESCRIPTION 
Facebook Lite Plus is an android application which provides you a good interface to login multiple facebook accounts with multiple mode and some other customizations.
This app doesn't collect any of your information all information provided by you directly collected by facebook. It is verified from Google play protect.
This app is in beta phase so maybe you can encounter with bugs and crashes.
#
# FEATURES
- Improve ui.
- Support multiple accounts login.
- Multiple methods of login.
- You can store and define account info for each account separately.
- Improve cookies method.
- Facebook video download.
- Two modes of Facebook style in mobile and cookies method.
- You can export/import accounts in/from file.
- You can import accounts from cookies file make sure file follow define patterns.
#

# IMAGES
![alt text](https://github.com/zaidrao/Facebook-Lite-Plus/blob/main/Images/pic1.jpg)
#
![alt text](https://github.com/zaidrao/Facebook-Lite-Plus/blob/main/Images/pic2.jpg)
#
![alt text](https://github.com/zaidrao/Facebook-Lite-Plus/blob/main/Images/pic3.jpg)
#
#
# FUTURE UPDATES
In future if I got good response from you I'll definitely update it.
If you encounter any bug, error and crash you can contact me on facebook.
#
# DOWNLOAD
<!-- Click the download button to download latest release app. -->
[<img src="https://play.google.com/intl/en_us/badges/images/generic/en-play-badge.png"
     alt="Get it on Google Play"
     height="80">](https://play.google.com/store/apps/details?id=com.zrstore.liteplus)
<!-- BEGIN LATEST DOWNLOAD BUTTON -->
<!-- [![Download apk](https://custom-icon-badges.herokuapp.com/badge/-Download-blue?style=for-the-badge&logo=download&logoColor=white "Download apk")](https://github.com/zaidrao/Facebook-Lite-Plus/releases/download/15/Lite+.1.5.apk) -->
<!-- END LATEST DOWNLOAD BUTTON -->
